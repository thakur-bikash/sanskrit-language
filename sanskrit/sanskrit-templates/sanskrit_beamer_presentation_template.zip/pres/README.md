# संस्कृत-शिक्षण-प्रस्तुतिः — Sanskrit Teaching Presentation Template

A **Beamer** presentation template for Sanskrit teaching.  
Type only Sanskrit — all layout, colour, and typography is automatic.

---

## Prerequisites (Overleaf setup)

| What | Value |
|------|-------|
| **Compiler** | **XeLaTeX** — _must_ be set in Overleaf → Menu → Compiler |
| **Fonts needed** | Shobhika-Bold · Linux Libertine O (both on Overleaf) |
| **Fallback font** | If Shobhika is missing, change both to `Noto Serif Devanagari` in `preambles/fonts.tex` |

---

## File layout

```
.
├── main.tex                        ← ONLY FILE YOU EVER EDIT
├── preambles/
│   ├── fonts.tex                   ← font setup (don't touch)
│   ├── theme.tex                   ← colours & slide design (don't touch)
│   └── commands.tex                ← all macros (reference only)
├── slides/
│   ├── 00_title.tex                ← title + outline (edit the list)
│   ├── 01_paricaya.tex             ← full example lesson
│   ├── TEMPLATE_nayi_prasuti.tex   ← COPY THIS for each new lesson
│   └── 99_samapti.tex              ← closing slide
└── graphics/                       ← put image files here
```

---

## How to add a new lesson

1. Copy `slides/TEMPLATE_nayi_prasuti.tex` → `slides/02_your_topic.tex`
2. Fill in your Sanskrit text (everything in `[ ]` brackets)
3. In `main.tex`, add: `\input{slides/02_your_topic}`
4. Compile with XeLaTeX

---

## Commands — Quick Reference

### Slide wrappers (one command = one full slide)

| Command | What it makes |
|---------|--------------|
| `\vibhagaphalam{विभागनाम}` | Bold section-divider (dark full screen) |
| `\sutraphalam{१.१.१}{सूत्रम्}` | Sūtra display slide |
| `\shlokaphalam{शीर्षकम्}{content}` | Centred verse slide |
| `\vivritiphalam{शीर्षकम्}{content}` | General explanation slide |
| `\dvistambhaphalam{शीर्षकम्}{left}{right}` | Two-column slide |
| `\bindustikhaphalam{शीर्षकम्}{\item…}` | Bullet-list slide |
| `\chitraphalam{शीर्षकम्}{graphics/file}{text}` | Image + text slide |

### Content blocks (use inside any frame)

| Command | What it makes |
|---------|--------------|
| `\sutram{१.१.१}{सूत्रम्}` | Boxed sūtra (maroon header, gray body) |
| `\shloka{verse text}` | Centred verse with gold rules |
| `\udaharana{example}` | Blue example box |
| `\apavada{exception}` | Red alert box |
| `\vigraha{analysis}` | Analysis box |
| `\nirnaya{conclusion}` | Bold conclusion box |

### Inline text markers

| Command | Effect |
|---------|--------|
| `\padam{शब्दः}{gloss}` | Term in maroon + gloss in gold |
| `\dhatu{भू}` | Verbal root with √ in saffron |
| `\pratyaya{suffix}` | Underlined suffix in blue |
| `\samjna{संज्ञा}` | Technical term in «guillemets» |
| `\udahara{word}` | Italic example word in gold |
| `\bhasya{quote}` | Commentary quotation in red |
| `\texten{English}` | Switch to Latin font |

### Progressive reveal (click-by-click)

```latex
\begin{frame}{शीर्षकम्}
  \begin{itemize}
    \item<1-> प्रथमः अंशः     % shows from click 1
    \item<2-> द्वितीयः अंशः   % shows from click 2
    \item<3-> तृतीयः अंशः     % shows from click 3
  \end{itemize}
  \uncover<4->{
    \nirnaya{अन्तिमनिर्णयः}   % shows from click 4
  }
\end{frame}
```

---

## Changing the colour scheme

Open `preambles/theme.tex` and edit the colour definitions at the top:

```latex
\definecolor{MaroonDeep}  {HTML}{5C1A1A}   % header/frame title background
\definecolor{SaffronGold} {HTML}{D4820A}   % accents, rules, slide numbers
\definecolor{CreamWhite}  {HTML}{FFF8F0}   % slide background
```

---

## Changing the presentation metadata

In `main.tex`, edit these lines:

```latex
\newcommand{\PrastutiNama}{प्रस्तुतेः नाम}   % presentation title
\newcommand{\VishayanNama}{विषयस्य नाम}       % subtitle / topic
\newcommand{\ShikshakaName}{शिक्षकस्य नाम}   % teacher name
\newcommand{\SansthaNama}{संस्थायाः नाम}      % institution
```
