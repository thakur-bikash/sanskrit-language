Place image files (.png .jpg .pdf) here
