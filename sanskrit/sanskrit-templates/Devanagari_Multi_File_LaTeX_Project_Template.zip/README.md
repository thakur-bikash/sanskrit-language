# Multi-Language Devanagari LaTeX Template

A modular XeLaTeX template structured for typesetting traditional Indian texts with commentaries. It supports Sanskrit, Hindi, Maithili, and English using the `polyglossia` and `fontspec` packages.

## Prerequisites

To compile this project, you need:
* **LaTeX Engine:** XeLaTeX (strictly required for OpenType font support).
* **Fonts:** * [Shobhika](https://github.com/Sanskrit-Research-Institute/Shobhika) (for Devanagari: Sanskrit, Hindi, Maithili)
  * [Linux Libertine O](https://libertine-fonts.org/) (for Latin/English)

## Directory Structure

```text
.
├── main.tex                 # Main compilation file
├── preambles/               # Configuration files
│   ├── packages.tex         # LaTeX package imports
│   ├── fonts.tex            # Font family definitions
│   ├── commands.tex         # Custom macros and environments
│   └── layout.tex           # Page geometry, spacing, and headers
├── content/                 # Text source files
│   ├── frontmatter.tex      # Title pages, copyright, dedications
│   ├── bhumika.tex          # Sanskrit preface
│   └── devanagari.tex       # Hindi/Sanskrit main content sections
└── graphics/                # Image files (e.g., portrait.png)